package aula2602;

public class App2 {
	public static void main (String[] args) {
		
		System.out.println(Math.abs(-10));
		System.out.println(Math.sqrt(625));
		System.out.println(Math.pow(2,3));
		System.out.println((int)(Math.random()*10));
		
	}
}
